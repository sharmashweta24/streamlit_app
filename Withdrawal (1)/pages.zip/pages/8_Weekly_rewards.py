
from os.path import abspath, join, dirname
from sys import path, exc_info

base_dir = abspath(join(dirname(__file__), "../"))
path.append(base_dir)

import streamlit as st
from datetime import datetime
import pandas as pd
from core.weekly_rewards import *
from app import *
from datetime import datetime

# Initialize session state variables
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False


def roi_rewards():
    st.title("ROI Transactions Processor")

    if st.session_state.logged_in:
        start_date = st.date_input("Select Start Date")

        if st.button("Process Transactions"):
            if not start_date:
                st.error("Please select a start date.")
            else:
                with st.spinner('Processing transactions...'):
                    transactions = fetch_transactions(start_date)
                    results = process_transactions(transactions)

                    df = pd.DataFrame(results)

                    if df.empty:
                        st.error("No transactions found for the selected date.")
                        return
                    
                csv_filename = datetime.now().strftime("%Y-%m-%d %H-%M-%S")+" weekly_rewards.csv"
                st.download_button(
                    label="Download CSV",
                    data=df.to_csv(index=False),
                    file_name=csv_filename,
                    mime="text/csv",
                )
                st.success(f"CSV file '{csv_filename}' generated successfully.")
                st.balloons()

    else:
        st.subheader("Please log in to continue")


# Login check
if not st.session_state.logged_in:
    login(st, "Adminname", "Password")
else:
    roi_rewards()